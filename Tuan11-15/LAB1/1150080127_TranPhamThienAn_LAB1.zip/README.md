Họ và tên: Trần Phạm Thiên Ân  
MSSV: 1150080127  
Lớp: 11_ĐH_CNPM2  
Tên bài LAB: Lab 1 - Mã hóa đối xứng cổ điển

Nội dung đã thực hiện:

- Xây dựng chương trình Java Swing bằng NetBeans và Maven để thực hành sáu thuật toán: Caesar, Vigenère, Rail Fence, Playfair, Transposition và Autokey.
- Thiết kế form riêng cho từng thuật toán, gồm các ô nhập bản rõ, khóa, bản mã và các nút mã hóa, giải mã, mở và lưu file văn bản.
- Tạo form tổng hợp để chọn thuật toán và thực hiện mã hóa, giải mã trên cùng một cửa sổ.
- Kết nối chương trình với Microsoft SQL Server, lưu lịch sử thao tác vào bảng dbo.history và hiển thị lại trên form lịch sử.
- Thực hiện ba thí nghiệm phân tích: vét cạn khóa Caesar, thống kê tần suất chữ cái và suy ra đoạn khóa Vigenère khi biết trước bản rõ.
- Tạo menu chính để mở các form và viết nhận xét về điểm yếu của sáu thuật toán trong báo cáo.

Kết quả thực hiện:

- Chạy được các form và thu được kết quả mã hóa khớp bộ dữ liệu mẫu: Caesar cho KHOOR, Vigenère cho RIJVS, Rail Fence cho HOREL OLLWD, Playfair cho GYIZSCOKCFBU, Transposition cho AAOTBM và Autokey cho RIJSS.
- Kết nối thành công với database LAB1_MaHoaCoDien. Form lịch sử và truy vấn trên Azure Data Studio cùng hiển thị sáu bản ghi ENCRYPT, mỗi thuật toán một lần. Các bản ghi này đều dùng bản rõ HELLO.
- Thử đủ 26 khóa Caesar với KHOOR, chương trình tìm được khóa 3 và bản rõ HELLO.
- Thống kê được 23 chữ cái trong bản mã PHHW PH DIWHU WKH WRJD SDUWB; chữ W xuất hiện 5 lần, chiếm khoảng 21,7%.
- Với cặp bản rõ HELLO và bản mã RIJVS, chương trình suy ra đoạn khóa KEYKE, phù hợp với khóa KEY lặp lại.
- Mở được form Caesar và form kết nối SQL từ menu chính; kết quả và hình ảnh thực hiện được trình bày trong báo cáo Word.

Các lưu ý cần thiết để giảng viên có thể kiểm tra hoặc chạy lại bài:

- Cần JDK 17 hoặc 21, Apache NetBeans từ bản 20 trở lên và Internet trong lần build đầu để Maven tải thư viện.
- Trong NetBeans, chọn File → Open Project → mở thư mục LAB1_TuLam, thực hiện Clean and Build rồi Run Project. Lớp chạy chính là week_01.frm_Menu.
- Thư mục LAB1_TuLam có pom.xml, mã nguồn Java và các file .form để mở lại giao diện trong GUI Builder.
- Cần có SQL Server đang chạy và cho phép kết nối TCP qua cổng 14333. Môi trường em sử dụng là SQL Server 2022 Express trong Docker trên macOS; Azure Data Studio dùng để chạy SQL thay SSMS.
- Đăng nhập SQL Server bằng tài khoản quản trị, chạy lần lượt 03_SQL_SERVER/01_Tao_CSDL.sql và 03_SQL_SERVER/02_Tao_Login.sql. Script tạo login dùng chế độ SQLCMD và biến LabPassword; người chạy tự truyền mật khẩu, file nộp không chứa mật khẩu SQL Server. Nếu login đã tồn tại, script không thay đổi mật khẩu của login đó.
- Trên form kết nối, nhập Server là 127.0.0.1, Port là 14333, Database là LAB1_MaHoaCoDien, User là lab1_user và mật khẩu đã đặt, sau đó bấm Test Connection.
- Sau khi kết nối, dùng form tổng hợp để mã hóa hoặc giải mã rồi bấm Xem lịch sử. Chạy 03_SQL_SERVER/03_Kiem_Tra_Du_Lieu.sql để đối chiếu dữ liệu trong database.
- Database mới tạo có bảng lịch sử trống; sáu bản ghi trong báo cáo là dữ liệu sinh ra khi em chạy bài, không được chèn sẵn trong script tạo database.
